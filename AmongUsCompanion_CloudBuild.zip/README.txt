Among Us Companion - Android project

Features:
- Movable floating bubble and expandable/minimizable panel.
- Manual player role notes.
- Speed selector from 10 to 100 (display only; does not change the game).
- Fake scanner-task demonstration.

It does NOT read hidden roles or modify the official Among Us game.

BUILD AN APK USING GITHUB ACTIONS
1. Sign in to GitHub and create a new empty repository.
2. Upload the CONTENTS of this folder (including the hidden .github folder).
3. Open the repository's Actions tab.
4. Select "Build Android APK" and press "Run workflow" if it has not started automatically.
5. When the run finishes, open it and download the "AmongUsCompanion-debug-apk" artifact.
6. Extract the downloaded artifact ZIP to get app-debug.apk.

The build uses Android Gradle Plugin 8.2.2, Gradle 8.2.1, JDK 17, and Android SDK 34.
The generated APK is a debug build and is not Play Store-ready.
Android may show security warnings for sideloaded APKs. Do not bypass Play Protect warnings.
